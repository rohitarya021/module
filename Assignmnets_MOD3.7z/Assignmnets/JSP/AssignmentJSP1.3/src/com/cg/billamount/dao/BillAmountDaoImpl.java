package com.cg.billamount.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.NamingException;

import com.cg.billamount.bean.BillAmount;
import com.cg.billamount.util.DbUtil;

public class BillAmountDaoImpl implements IBillAmountDao
{
	
	Connection con = null;
	PreparedStatement pstm = null;
	
	@Override
	
	public int addBillDetail(BillAmount ba) throws NamingException, SQLException
	{
		
		int genId = generateBillId();
		
		con=DbUtil.getConnection();
		String query = "INSERT INTO BILLDETAIL VALUES(?,?,?,?,?,SYSDATE)";
		
		pstm = con.prepareStatement(query);
		
		
		pstm.setInt(1, genId);
		pstm.setInt(2, ba.getConsumer_num());
		pstm.setDouble(3, ba.getCurr_reading());
		pstm.setDouble(4, ba.getUnitConsumer());
		pstm.setDouble(5, ba.getNetAmount());
		
		pstm.executeUpdate();
		
		return genId;
	}
	
	private int generateBillId()
	{
		int retirnId=0;
		
		try 
		{
			con = DbUtil.getConnection();
			String query ="select seq_bill_num.nextval from dual";
			
			pstm = con.prepareStatement(query);
			
			ResultSet rs = pstm.executeQuery();
			
			while(rs.next())
			{
				retirnId = rs.getInt(1); 
			}
		} 
		catch (NamingException | SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				con.close();
				pstm.close();
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
			
		}
		return retirnId;
	}

	
	
	
}
