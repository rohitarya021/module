package com.cg.eBill.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.eBill.bean.BillAmount;
import com.cg.eBill.bean.Consumers;
import com.cg.eBill.service.EBillServiceImpl;
import com.cg.eBill.service.IeBillService;


@WebServlet("*.do")
public class EBillContoller extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		processRequest(request, response);
	}
	
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		
		
		 String action = request.getServletPath();
		  
		    IeBillService servObj = new EBillServiceImpl();
		    HttpSession session = request.getSession();
		    
		    switch (action)
		    {
		    case "/listConsumer.do":
		      ArrayList<Consumers> consumersList = servObj.showAllConsumers();
		      
		     
		      session.setAttribute("consumerList", consumersList);
		      
		      		      
		      RequestDispatcher rdOne = getServletContext().getRequestDispatcher("/Show_ConsumerList.jsp");
		      rdOne.forward(request, response);
		          
		      break;
		      
		    case "/searchConsumerBill.do":
		      int id =Integer.parseInt(request.getParameter("consumerId"));
		      System.out.println(id);
		      ArrayList<BillAmount> consumersBills = servObj.searchConsumerBills(id);
		   
		      System.out.println(consumersBills);
		      
		      request.getSession().setAttribute("allBills", consumersBills);
		      request.getSession().setAttribute("consumerId", id);
		      RequestDispatcher rdTwo = getServletContext().getRequestDispatcher("/Show_bills.jsp");
		      rdTwo.forward(request, response);
		      
		      break;
		      
		    case "/showConsumerDetail.do":
			       id =Integer.parseInt(request.getParameter("consumerId"));
			   
			      Consumers consumer = servObj.searchConsumerDetail(id);
			      request.getSession().setAttribute("consumer", consumer);
			      RequestDispatcher rd = getServletContext().getRequestDispatcher("/Show_Consumer.jsp");
			      rd.forward(request, response);
			      
			      break;
			      
		    case "/addConsumerDetail.do":
		    	System.out.println("came here");
		    		id = (int) session.getAttribute("conId");
		    		int lastMnthRead = Integer.parseInt(request.getParameter("LMR"));
		    		int currMnthRead = Integer.parseInt(request.getParameter("CMR"));
		    		
		    		int unitConsumed = currMnthRead-lastMnthRead;
		    		double billAmt = unitConsumed*1.15 + 100;
		    		
		    		BillAmount ba = new BillAmount();
		    		ba.setConsumer_num(id);
		    		ba.setCurr_reading(currMnthRead);
		    		ba.setUnitConsumer(unitConsumed);
		    		ba.setNetAmount(billAmt);
		    		
		    	    servObj.addConsumerBill(ba);
		    	break;

		    default:
		      break;
		    }
		    
	}

}
