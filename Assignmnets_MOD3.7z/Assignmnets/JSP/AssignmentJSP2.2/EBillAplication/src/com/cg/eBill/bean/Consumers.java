package com.cg.eBill.bean;

public class Consumers 
{
	@Override
	public String toString() {
		return "Consumers [ID=" + ID + ", Name=" + Name + ", address="
				+ address + "]";
	}
	private int ID;
	private String Name;
	private String address;
	public Consumers() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Consumers(int iD, String name, String address) {
		super();
		ID = iD;
		Name = name;
		this.address = address;
	}
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	
}
