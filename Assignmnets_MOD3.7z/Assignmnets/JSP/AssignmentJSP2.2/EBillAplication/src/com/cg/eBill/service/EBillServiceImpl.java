package com.cg.eBill.service;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.NamingException;

import com.cg.eBill.bean.BillAmount;
import com.cg.eBill.bean.Consumers;
import com.cg.eBill.dao.EBillDAOImpl;
import com.cg.eBill.dao.IeBillDAO;



public class EBillServiceImpl implements IeBillService
{
	IeBillDAO daoObj = new EBillDAOImpl();
	
	@Override
	public ArrayList<Consumers> showAllConsumers() 
	{
		return daoObj.showAllConsumers();
	}

	@Override
	public ArrayList<BillAmount> searchConsumerBills(int id) 
	{
	
		return daoObj.searchConsumerBills(id);
	}
	
	@Override
	public Consumers searchConsumerDetail(int id) 
	{
		return daoObj.searchConsumerDetail(id);
	}

	@Override
	public void addConsumerBill(BillAmount ba) 
	{
		try {
			daoObj.addConsumerBill(ba);
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


}
