package com.cg.eBill.dao;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.NamingException;

import com.cg.eBill.bean.BillAmount;
import com.cg.eBill.bean.Consumers;

public interface IeBillDAO 
{
	public ArrayList<Consumers> showAllConsumers();
	public ArrayList<BillAmount> searchConsumerBills(int id);
	public Consumers searchConsumerDetail(int id);
	public void addConsumerBill(BillAmount ba) throws NamingException, SQLException;

}
