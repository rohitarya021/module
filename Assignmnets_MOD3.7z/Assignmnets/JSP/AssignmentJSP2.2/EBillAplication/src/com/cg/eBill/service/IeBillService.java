package com.cg.eBill.service;

import java.util.ArrayList;

import com.cg.eBill.bean.BillAmount;
import com.cg.eBill.bean.Consumers;

public interface IeBillService 
{
	public ArrayList<Consumers> showAllConsumers();
	public ArrayList<BillAmount> searchConsumerBills(int id);
	Consumers searchConsumerDetail(int id);
	void addConsumerBill(BillAmount ba);
}
