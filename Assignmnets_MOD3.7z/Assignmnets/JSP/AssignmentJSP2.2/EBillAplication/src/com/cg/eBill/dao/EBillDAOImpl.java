package com.cg.eBill.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.NamingException;

import com.cg.eBill.bean.BillAmount;
import com.cg.eBill.bean.Consumers;
import com.cg.eBill.util.DbUtil;

public class EBillDAOImpl implements IeBillDAO
{
	
	Connection con = null;
	PreparedStatement pstm = null;

	@Override
	public ArrayList<Consumers> showAllConsumers() 
	{
		ArrayList<Consumers> result=new ArrayList<Consumers>();
		try {
					
			con = DbUtil.getConnection();
			String queryOne = "SELECT * FROM consumer";
			pstm = con.prepareStatement(queryOne);
			
			ResultSet rs = pstm.executeQuery();
			
			
			while(rs.next())
			{
				Consumers cs  = new Consumers();
				cs.setID(rs.getInt(1));
				cs.setName(rs.getString(2));
				cs.setAddress(rs.getString(3));
							
				result.add(cs);
			}
		}
		catch (NamingException | SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				con.close();
				pstm.close();
			} 
			catch (SQLException e)
			{
				e.printStackTrace();
			}
		}
		
		return result;
	}

	@Override
	public ArrayList<BillAmount> searchConsumerBills(int id)
	{
		ArrayList<BillAmount> allBills=new ArrayList<>();
		
		try {
			con = DbUtil.getConnection();
			String queryOne = "SELECT * FROM billdetail WHERE consumer_num=?";
			pstm = con.prepareStatement(queryOne);
			pstm.setInt(1, id);
			ResultSet rs = pstm.executeQuery();
			
			
			while(rs.next())
			{
				BillAmount ba  = new BillAmount();
				ba.setBill_num(rs.getInt("bill_num"));
				ba.setConsumer_num(rs.getInt("consumer_num"));
				ba.setCurr_reading(rs.getInt("cur_reading"));
				ba.setUnitConsumer(rs.getInt("unitconsumed"));
				ba.setNetAmount(rs.getDouble("netamount"));
				ba.setCurrDate(rs.getDate("bill_date"));
						
							
				allBills.add(ba);
			}
			}
		catch (NamingException | SQLException e)
			{

			e.printStackTrace();
			}
		return allBills;
	}
	
	@Override
	public Consumers searchConsumerDetail(int id) 
	{
		Consumers cons = new Consumers();
		
		    try {
				con = DbUtil.getConnection();
				String query = "SELECT * FROM consumers WHERE consumer_num=?";
				PreparedStatement pstm = con.prepareStatement(query);
				pstm.setInt(1, id);
				
				ResultSet rs=pstm.executeQuery();
				
				if(rs.next())
				{
					cons.setID(id);
					cons.setName(rs.getString(2));
					cons.setAddress(rs.getString(3));
				}
			} 
		    catch (SQLException | NamingException e) 
		    {
				e.printStackTrace();
			}
		
		return cons;
	}

	
	@Override
	public void addConsumerBill(BillAmount ba) throws NamingException, SQLException
	{
		
		int genId = generateBillId();
		
		con=DbUtil.getConnection();
		String query = "INSERT INTO BILLDETAIL VALUES(?,?,?,?,?,SYSDATE)";
		
		pstm = con.prepareStatement(query);
		
		
		pstm.setInt(1, genId);
		pstm.setInt(2, ba.getConsumer_num());
		pstm.setDouble(3, ba.getCurr_reading());
		pstm.setDouble(4, ba.getUnitConsumer());
		pstm.setDouble(5, ba.getNetAmount());
		
		pstm.executeUpdate();
		
	}
	
	private int generateBillId()
	{
		int retirnId=0;
		
		try 
		{
			con = DbUtil.getConnection();
			String query ="select seq_bill_num.nextval from dual";
			
			pstm = con.prepareStatement(query);
			
			ResultSet rs = pstm.executeQuery();
			
			while(rs.next())
			{
				retirnId = rs.getInt(1); 
			}
		} 
		catch (NamingException | SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				con.close();
				pstm.close();
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
			
		}
		return retirnId;
	}


}
