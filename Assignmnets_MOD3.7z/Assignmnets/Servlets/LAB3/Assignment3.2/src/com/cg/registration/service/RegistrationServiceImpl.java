package com.cg.registration.service;

import java.sql.SQLException;

import javax.naming.NamingException;

import com.cg.model.exception.RegistrationException;
import com.cg.registration.dao.IregistrationDao;
import com.cg.registration.dao.RegistrationDaoImpl;
import com.cg.registration.dto.UserData;

public class RegistrationServiceImpl implements IregistrationService
{
	IregistrationDao daoObj = new RegistrationDaoImpl();
	
	@Override
	public void addDetails(UserData obj) throws RegistrationException
	{
		try
		{
			daoObj.addDetails(obj);
		} 
		catch (SQLException | NamingException e) 
		{
			e.printStackTrace();
			throw new RegistrationException("failed to add the entry");
		}
	}

}
