package com.cg.registration.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.model.exception.RegistrationException;
import com.cg.registration.dto.UserData;
import com.cg.registration.model.util.DbUtil;
import com.cg.registration.service.IregistrationService;
import com.cg.registration.service.RegistrationServiceImpl;

@WebServlet("/RegistrationController")
public class RegistrationController extends HttpServlet 
{
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		processRequest(request, response);
	}
	
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out = response.getWriter();
		
		IregistrationService servObj = new RegistrationServiceImpl();
		
		String fName =  request.getParameter("fName");
		String lName = request.getParameter("lName");
		String pwd = request.getParameter("pwd");
		String gender = request.getParameter("gender");
		String [] skill = request.getParameterValues("skill");
		String city = request.getParameter("city");
		
		UserData usr = new UserData();
		usr.setfName(fName);
		usr.setlName(lName);
		usr.setGender(gender);
		usr.setSkill(skill);
		usr.setCity(city);
		usr.setPwd(pwd);
		
		try 
		{
			servObj.addDetails(usr);
			response.sendRedirect("Registration.html");
		}
		catch (RegistrationException e) 
		{
			out.println("<p>"+e.getMessage()+"</p>");
			e.printStackTrace();
		}
		
	}

}
