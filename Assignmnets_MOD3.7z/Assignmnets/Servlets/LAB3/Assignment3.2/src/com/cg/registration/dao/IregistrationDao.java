package com.cg.registration.dao;

import java.sql.SQLException;

import javax.naming.NamingException;

import com.cg.model.exception.RegistrationException;
import com.cg.registration.dto.UserData;

public interface IregistrationDao
{

	public void addDetails(UserData obj) throws RegistrationException, SQLException, NamingException;
	
}
