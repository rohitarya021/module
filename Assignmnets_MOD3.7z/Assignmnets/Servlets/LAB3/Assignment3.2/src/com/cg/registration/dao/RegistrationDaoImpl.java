package com.cg.registration.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.naming.NamingException;

import com.cg.registration.dto.UserData;
import com.cg.registration.model.util.DbUtil;

public class RegistrationDaoImpl implements IregistrationDao
{

	@Override
	public void addDetails(UserData obj) throws SQLException, NamingException 
	{
		
		String concatSkills = String.join(",", obj.getSkill());
		
			Connection con = DbUtil.getConnection();
			String query = "INSERT INTO registrationdetails VALUES(?,?,?,?,?,?)";
			PreparedStatement pstm = con.prepareStatement(query);
			pstm.setString(1, obj.getfName());
			pstm.setString(2, obj.getlName());
			pstm.setString(3, obj.getPwd());
			pstm.setString(4, obj.getGender());
			pstm.setString(5, concatSkills);
			pstm.setString(6, obj.getCity());
			
			pstm.executeUpdate();
			
		
	}

}
