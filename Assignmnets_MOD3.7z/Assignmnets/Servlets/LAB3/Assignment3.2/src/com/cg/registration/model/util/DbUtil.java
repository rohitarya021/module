package com.cg.registration.model.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DbUtil
{
	public static Connection getConnection() throws SQLException, NamingException
	{
		InitialContext context = new InitialContext();
		DataSource ds = (DataSource) context.lookup("java:/myDS");
		return ds.getConnection();
	}
}
