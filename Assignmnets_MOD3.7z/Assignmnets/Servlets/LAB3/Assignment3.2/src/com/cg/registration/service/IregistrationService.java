package com.cg.registration.service;


import com.cg.model.exception.RegistrationException;
import com.cg.registration.dto.UserData;

public interface IregistrationService 
{
	public void addDetails(UserData obj) throws RegistrationException;
}
