package com.capgemini.web.assignmnet_2_1;

import java.awt.print.Printable;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Locale;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/FormSubmission")
public class FormSubmission extends HttpServlet 
{
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String name = request.getParameter("uName");
		String pass = request.getParameter("uPass");
		String mime = request.getContentType();
		Locale local =  request.getLocale();
		
		int data = request.getContentLength();
		
		
		response.setContentType("text/html");
		
		PrintWriter out = null;
		
		if(name.equals("admin") && pass.equals("pass123"))
		{
			
			
			out = response.getWriter();
			
			out.println("<html>");
			out.println("<body>");
			out.println("<p>Success</p>");
			out.println("<p>Mime : " + mime + "</p>");
			out.println("<p>Locale : " + local.toString() + "</p>");
			out.println("<p>Data : " + data + "</p>");
			out.println("</body>");
			out.println("</html>");
		}

		else
		{
			
			
			out = response.getWriter();
			
			out.println("<html>");
			out.println("<body>");
			out.println("<p>Failure</p>");
			out.println("<p>Mime : " + mime + "</p>");
			out.println("<p>Locale : " + local.toString() + "</p>");
			out.println("<p>Data : " + data + "</p>");
			out.println("</body>");
			out.println("</html>");
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request, response);
	}

}
