package com.cg.billamount.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.billamount.bean.BillAmount;
import com.cg.billamount.exception.BillAmountException;
import com.cg.billamount.service.BillAmountServImpl;
import com.cg.billamount.service.IBillAmountServ;

@WebServlet("*.mvc")
public class BillServlet extends HttpServlet 
{
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		processRequest(request, response);
	}

	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String action  =  request.getServletPath();
		HttpSession session =  request.getSession();
		IBillAmountServ servObj = new BillAmountServImpl();
		
		switch (action) 
		{
		case "/BillServlet.mvc":
				
				String uName =  request.getParameter("uName");
				String pwd = request.getParameter("pwd");
			
				
				PrintWriter out = response.getWriter();
			
				
				if(uName.equals("rima") && pwd.equals("password"))
					{		
						session.setAttribute("userName" , uName);
			
						response.sendRedirect("User_Info.jsp");
					}
			
				else
					{
						response.sendRedirect("LoginPage.html");
					}
		
				
			
			break;
			
		case "/CalculateBill.mvc":
					int lastMnthR = Integer.parseInt(request.getParameter("LMR"));
					int CurrMnthR =  Integer.parseInt(request.getParameter("CMR"));
					
					double totalBill= (CurrMnthR-lastMnthR)*1.15 + 100;
					out = response.getWriter();
					
					BillAmount ba = new BillAmount();
					ba.setConsumer_num(Integer.parseInt(request.getParameter("consumerNo")));
					ba.setCurr_reading(CurrMnthR);
					ba.setNetAmount(totalBill);
					ba.setUnitConsumer(CurrMnthR-lastMnthR);
					
			try 
			{
				servObj.addBillDetail(ba);
			} 
			catch (BillAmountException e) 
			{
				e.printStackTrace();
				response.sendRedirect("errorPage.html");
			}
					out.println
						(
								"<html>" +
								"<head>" +
								"<meta charset='ISO-8859-1'>" +
								"<title>Insert title here</title>" +
								"</head>" +
								"<body>" +
								
								"<p>Welcome "+ session.getAttribute("userName")+ "<p>" +
								
								"<h1>Electricity bill for consumer number - "+ ba.getConsumer_num() +"<h1>" +
								
								"<h4>Unit consumed - "+ (CurrMnthR-lastMnthR)+"<h4>" +
								"<h4>Net amount - "+ totalBill +"<h4>" +
									
								"</body>" +
								"</html>" 
						);
					
					
			break;

		default:
			break;
		}
	}
}
