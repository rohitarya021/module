package com.cg.billamount.bean;

import java.io.Serializable;
import java.sql.Date;

public class BillAmount implements Serializable
{
	private int bill_num;
	private int consumer_num;
	private int curr_reading;
	private int unitConsumer;
	private double netAmount;
	private Date currDate;
	
	public BillAmount() 
	{
		super();
	}

	public BillAmount(int bill_num, int consumer_num, int curr_reading,
			int unitConsumer, int netAmount, Date currDate) 
	{
		super();
		this.bill_num = bill_num;
		this.consumer_num = consumer_num;
		this.curr_reading = curr_reading;
		this.unitConsumer = unitConsumer;
		this.netAmount = netAmount;
		this.currDate = currDate;
	}

	public int getBill_num() {
		return bill_num;
	}

	public void setBill_num(int bill_num) {
		this.bill_num = bill_num;
	}

	public int getConsumer_num() {
		return consumer_num;
	}

	public void setConsumer_num(int consumer_num) {
		this.consumer_num = consumer_num;
	}

	public int getCurr_reading() {
		return curr_reading;
	}

	public void setCurr_reading(int curr_reading) {
		this.curr_reading = curr_reading;
	}

	public int getUnitConsumer() {
		return unitConsumer;
	}

	public void setUnitConsumer(int unitConsumer) {
		this.unitConsumer = unitConsumer;
	}

	public double getNetAmount() {
		return netAmount;
	}

	public void setNetAmount(double totalBill) {
		this.netAmount = totalBill;
	}

	public Date getCurrDate() {
		return currDate;
	}

	public void setCurrDate(Date currDate) {
		this.currDate = currDate;
	}
	
	
	
	
}
