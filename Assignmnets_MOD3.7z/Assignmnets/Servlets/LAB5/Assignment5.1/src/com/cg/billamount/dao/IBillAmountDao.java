package com.cg.billamount.dao;

import java.sql.SQLException;

import javax.naming.NamingException;

import com.cg.billamount.bean.BillAmount;

public interface IBillAmountDao
{
	public int addBillDetail(BillAmount ba) throws NamingException, SQLException;
}
