package com.cg.billamount.service;

import java.sql.SQLException;

import javax.naming.NamingException;

import com.cg.billamount.bean.BillAmount;
import com.cg.billamount.exception.BillAmountException;

public interface IBillAmountServ 
{
	public int addBillDetail(BillAmount ba) throws BillAmountException;
}
