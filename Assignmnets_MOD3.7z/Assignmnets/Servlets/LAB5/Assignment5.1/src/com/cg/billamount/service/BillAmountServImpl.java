package com.cg.billamount.service;

import java.sql.SQLException;

import javax.naming.NamingException;
import javax.swing.text.StyledEditorKit.BoldAction;

import com.cg.billamount.bean.BillAmount;
import com.cg.billamount.dao.BillAmountDaoImpl;
import com.cg.billamount.dao.IBillAmountDao;
import com.cg.billamount.exception.BillAmountException;

public class BillAmountServImpl implements IBillAmountServ
{
 IBillAmountDao objDao = new BillAmountDaoImpl();

	@Override
	public int addBillDetail(BillAmount ba) throws BillAmountException 
	{
		int id=0;
		try 
		{
			id= objDao.addBillDetail(ba);
		} 
		catch (NamingException | SQLException e) 
		{
			e.printStackTrace();
			throw new BillAmountException("invalid consumer number");
		}
		return id;
	}
	
}
