package com.capgemini.tcc.junittest;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.PatientDAO;
import com.capgemini.tcc.exception.PatientException;



public class PatientDAOTest 
{

PatientBean prod=null;
PatientDAO prodDao=null;
@Before
public void callBefore(){
	prod=new PatientBean();
	prod.setPatientName("aaaa");
	prod.setPatientAge(34);
	prod.setPatientPhone(12344555);
	prod.setPatientDesc("fever");
	
	prodDao=new PatientDAO();
}
@Test
public void myTestCase() throws PatientException{
	assertEquals(1004,prodDao.addPatientDetails(prod));
	
}
@After
public void callAfter(){
	
}

}
