package com.capgemini.tcc.bean;

import java.sql.Date;

public class PatientBean 
{
 private int patientId;
 private String patientName;
 private int patientAge;
 private double patientPhone;
 private String patientDesc;
 private Date consultationdate;

 public Date getConsultationdate() {
	return consultationdate;
}
public void setConsultationdate(Date consultationdate) {
	this.consultationdate = consultationdate;
}
public PatientBean() {
	super();
	// TODO Auto-generated constructor stub
}
public PatientBean(int patientId, String patientName, int patientAge,
		double patientPhone, String patientDesc) {
	super();
	this.patientId = patientId;
	this.patientName = patientName;
	this.patientAge = patientAge;
	this.patientPhone = patientPhone;
	this.patientDesc = patientDesc;
}
public int getPatientId() {
	return patientId;
}
public void setPatientId(int patientId) {
	this.patientId = patientId;
}
public String getPatientName() {
	return patientName;
}
public void setPatientName(String patientName) {
	this.patientName = patientName;
}
public int getPatientAge() {
	return patientAge;
}
public void setPatientAge(int patientAge) {
	this.patientAge = patientAge;
}
public double getPatientPhone() {
	return patientPhone;
}
public void setPatientPhone(double patientPhone) {
	this.patientPhone = patientPhone;
}
public String getPatientDesc() {
	return patientDesc;
}
public void setPatientDesc(String patientDesc) {
	this.patientDesc = patientDesc;
}
@Override
public String toString() {
	return "PatientBean [patientId=" + patientId + ", patientName="
			+ patientName + ", patientAge=" + patientAge + ", patientPhone="
			+ patientPhone + ", patientDesc=" + patientDesc + "]";
}
 
}
