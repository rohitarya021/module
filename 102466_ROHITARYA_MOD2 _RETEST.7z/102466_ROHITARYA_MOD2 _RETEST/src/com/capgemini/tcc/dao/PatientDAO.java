package com.capgemini.tcc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;
import com.capgemini.tcc.util.DbUtil;






public class PatientDAO implements IPatientDAO{
	
	private static final Logger mylogger=Logger.getLogger(DbUtil.class);
	static Connection con=null;
	static PreparedStatement pstm=null;

	@Override
	public int addPatientDetails(PatientBean patient) throws PatientException
	{

		int status=0;
		int idReturn=0;
		// TODO Auto-generated method stub
		con=DbUtil.getConnection();
		int patientId= patientId();
		String query="INSERT INTO Patient VALUES(?,?,?,?,?,sysdate)";
		try {
			pstm=con.prepareStatement(query);
			pstm.setInt(1,patientId);
			pstm.setString(2,patient.getPatientName());
			pstm.setInt(3,patient.getPatientAge());
			pstm.setDouble(4,patient.getPatientPhone());
			pstm.setString(5,patient.getPatientDesc());
			
			
			 status=pstm.executeUpdate();
			 mylogger.info(" SUCCESSFULL ADDITION OF DETAILS  ");
				
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			mylogger.info(" some error has occured  ");
			
			throw new PatientException(" Problem In Insert..");
		}
		finally{
			try {
				pstm.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
			 	return patientId ;
	
		
	
	
	}
	
	private int patientId() throws PatientException {
		int Id=0;
		try {
			con=DbUtil.getConnection();
        String queryFive="SELECT PATIENT_ID_SEQ.nextval FROM DUAL";
  pstm=con.prepareStatement(queryFive);
  ResultSet resTwo=pstm.executeQuery();
while(resTwo.next()){
	Id=resTwo.getInt(1);
	
	
	
	
	
}

mylogger.info(" SUCCESFULL ADDITION OFDETAILS   ");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			mylogger.info(" some error has occured while ADDING  ");
			
			
			throw new PatientException("Problem in Getting Id");
		}
		return Id;
	}

	@Override
	public PatientBean getPatientDetails(int patientId) throws PatientException {
		
		PatientBean pat=null;
		
		
		System.out.println(" In Dao....");
		List<PatientBean> myList=new ArrayList<PatientBean>();
		con=DbUtil.getConnection();
		String queryTwo=
"SELECT patient_name,age,phone,description,consultation_date FROM Patient";
		
		try {
			pstm=con.prepareStatement(queryTwo);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		ResultSet res;
		try {
			res = pstm.executeQuery();
			while(res.next()){
				 pat=new PatientBean();
				
				pat.setPatientName(res.getString("patient_name"));
				pat.setPatientAge(res.getInt("age"));
				pat.setPatientPhone(res.getDouble("phone"));
				pat.setPatientDesc(res.getString("description"));
				pat.setConsultationdate(res.getDate("consultation_date"));
				
				
				
				
			}
			
			mylogger.info(" SUCCESSFULL SEARCHING OPERATION PERFORMED  ");
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			mylogger.info(" some error has occured  while searching");
		}
		
			
		finally{
			
			try {
				pstm.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} 
	
		
		return pat;
	

	}


	}


