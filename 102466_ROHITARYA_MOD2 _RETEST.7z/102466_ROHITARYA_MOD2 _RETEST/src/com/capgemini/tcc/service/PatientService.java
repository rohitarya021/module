package com.capgemini.tcc.service;

import java.sql.SQLException;

import java.util.List;
import java.util.regex.Pattern;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.IPatientDAO;
import com.capgemini.tcc.dao.PatientDAO;
import com.capgemini.tcc.exception.PatientException;




public class PatientService implements IPatientService 
{

	IPatientDAO patientDAO=new PatientDAO();
	
	
	@Override
	public int addPatientDetails(PatientBean patient) throws PatientException {
		// TODO Auto-generated method stub
		 return patientDAO.addPatientDetails(patient);
	}


	


	@Override
	public PatientBean getPatientDetails(int patientId) throws PatientException {
		// TODO Auto-generated method stub
		return patientDAO.getPatientDetails(patientId);
	}
	public static boolean 
	validateName(String pattName,String pattPattern) throws PatientException{
		
	boolean validation=Pattern.matches(pattPattern,pattName);
	if(!validation){
throw new PatientException("First Letter should be capital min3 max20");
	}
	
	return validation;
	
	
}
}